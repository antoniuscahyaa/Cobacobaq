# Rencana Lari: paket APK

Paket ini membungkus aplikasi Rencana Lari menjadi file APK Android. APK dibangun otomatis oleh GitHub (gratis), jadi kamu tidak perlu Android Studio.

## Langkah

1. Buat akun GitHub kalau belum punya, lalu buat repositori baru (boleh private), misalnya `rencana-lari`.
2. Unggah seluruh isi folder ini ke repositori itu, termasuk folder tersembunyi `.github`.
   - Di komputer: buka repositori, pilih Add file > Upload files, lalu seret semua isi folder (termasuk folder `.github`).
   - Kalau folder `.github` tidak ikut terunggah: pilih Add file > Create new file, ketik nama `.github/workflows/build-apk.yml` di kolom nama, lalu tempel isi file `.github/workflows/build-apk.yml` dari paket ini.
3. Buka tab Actions di repositori, pilih Build APK, lalu tekan Run workflow. Prosesnya sekitar 5-10 menit.
4. Setelah ada tanda centang hijau, buka hasil jalannya (run), turun ke bagian Artifacts, dan unduh `rencana-lari-apk`. Ekstrak ZIP-nya untuk mendapat `app-debug.apk`.
5. Kirim `app-debug.apk` ke HP, lalu pasang. Android akan meminta izin "Pasang dari sumber tidak dikenal" untuk aplikasi yang kamu pakai membukanya (misalnya Files atau Chrome).

## Catatan

- APK ini versi debug untuk dipakai sendiri, bukan untuk diunggah ke Play Store.
- Data di aplikasi terpisah dari versi web. Untuk memindahkan data dari versi web: buka bagian "Cadangan data" di versi web, tekan "Salin cadangan", simpan teksnya, lalu di aplikasi APK tempel di kotak teks dan tekan "Pulihkan dari teks" dua kali.
- Font tampilan diambil dari Google Fonts saat HP terhubung internet. Tanpa internet, aplikasi tetap jalan dengan font bawaan HP, hanya tampilan hurufnya sedikit berbeda. Semua fitur lain bekerja tanpa internet.
- Kalau mengubah `www/index.html`, unggah ulang file itu ke repositori. Workflow berjalan lagi otomatis dan menghasilkan APK baru.
